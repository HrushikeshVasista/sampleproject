
/**
 * This class describes the behavior of class Dog
 * 
 * @author Hrushikesh Vasista, Vedant Godhamgaonkar 
 * @version Assignment-1
 */
public class Dog extends Mammal
{
    // instance variables - replace the example below with your own
    private int ID;
    
   /**
     * This class describes the behavior of class Dog with methods such as eat,move etc.
     * 
     * @return     Dog details 
     */
   
    /**
     * Constructor for objects of class Dog
     */
    public Dog()
    {
        // initialise instance variables
        x = 0;
    }


    
}
