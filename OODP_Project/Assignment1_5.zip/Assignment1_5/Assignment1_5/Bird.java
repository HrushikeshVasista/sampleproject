
/**
 * Abstract class Bird - describes the features of a bird
 * 
 * @author Hrushikesh Vasista, Vedant Godhamgaonkar
 * @version Assignment-1
 */
public abstract class Bird
{
    int flyingSpeed();
    
}
