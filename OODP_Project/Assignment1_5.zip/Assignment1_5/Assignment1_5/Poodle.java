
/**
 * This class describes the behavior of class Poodle
 * 
 * @author Hrushikesh Vasista, Vedant Godhamgaonkar 
 * @version Assignment-1
 */
public class Poodle extends Dog
{
    // instance variables - replace the example below with your own
    private String breed;
    
    
   /**
     * This class describes the behavior of class Poodle which inherits the properties of Class Dog.
     * 
     * @return     Poodle details 
     */

    /**
     * Constructor for objects of class Poodle
     */
    public Poodle()
    {
        // initialise instance variables
        x = 0;
    }

    
    public int sampleMethod(int y)
    {
        // put your code here
        return x + y;
    }
}
