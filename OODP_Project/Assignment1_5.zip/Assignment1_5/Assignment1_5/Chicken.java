
/**
 * This class describes the behavior of class Chicken
 * 
 * @author Hrushikesh Vasista, Vedant Godhamgaonkar 
 * @version Assignment-1
 */
public class Chicken extends Bird
{
    // instance variables - replace the example below with your own
    private int x;

    /**
     * Constructor for objects of class Chicken
     */
    
   /**
     * This class describes the behavior of class Chicken with methods such as eat,move etc.
     * 
     * @return     Chicken details 
     */
    
    public Chicken()
    {
        // initialise instance variables
        x = 0;
    }


    public int sampleMethod(int y)
    {
        // put your code here
        return x + y;
    }
}
