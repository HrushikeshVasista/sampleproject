
/**
 * Abstract class Mammal - describes features of a mammal
 * 
 * @author Hrushikesh Vasista, Vedant Godhamgaonkar
 * @version Assignment-1
 */
public abstract class Mammal
{
    private int age;
     /**
     * An example of a method - replace this comment with your own
     * 
     * @param  y    a sample parameter for a method
     * @return        the sum of x and y 
     */
    int movingSpeed();
    
    
    
}
