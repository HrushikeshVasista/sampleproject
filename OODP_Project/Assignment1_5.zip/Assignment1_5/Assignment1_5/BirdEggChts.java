
/**
 * Write a description of interface BirdEggChts here.
 * 
 * @author Hrushikesh Vasista, Vedant Godhamgaonkar 
 * @version Assignment-1
 */
public interface BirdEggChts
{
    /**
     * An example of a method header - replace this comment with your own
     * 
     * @param  y    a sample parameter for a method
     * @return        the result produced by sampleMethod 
     */
    int sampleMethod(int y);
}
